// Hier können Lösungen für verschiedene Aufgaben gespeichert werden.
// Beispiel: Aufgabe 1
let text = await getInput("Geben Sie einen Text ein:");
print("Eingegebener Text: " + text);

// Aufgabe 2: Zahlen addieren
// ...
