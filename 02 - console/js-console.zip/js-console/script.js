let text = await getInput("Geben sie einen Text ein");
print("Eingegebener Text: " + text);
